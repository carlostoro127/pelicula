<?php
include("conexion.php");
session_start();
if(!isset($_SESSION["session_username"])) {
header("location:login.php");
} else {
?>
<head>
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" />
  <title>Actualizando</title>
  
  <link rel="stylesheet" href="example/example.css">
  <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>

  <!-- This is what you need -->
  <script src="dist/sweetalert.min.js"></script>
  <link rel="stylesheet" href="dist/sweetalert.css">
  <!--.......................-->
  </head>
  <iframe src="sweetalert.html" style="display:none;"></iframe>
<?php



$nombre=$_REQUEST['nombre']; 
$sinopsis=$_REQUEST['sinopsis']; 
$year=$_REQUEST['year']; 
$id=$_REQUEST['id'];

if($nombre=="" && $sinopsis=="" && $year=="")
{
echo "

<script>

swal({
  title: 'Error',
  text: 'Debe diligenciar almenos un campo para que pueda ser actualizado',
  type: 'error',
  showCancelButton: false,
  confirmButtonColor: '#A1D9F2',
  confirmButtonText: 'Volver atras',
  closeOnConfirm: true
});



</script>";	
}



if($nombre!="")
{
$Modifica="update pelicula  set nombre='".$nombre."' WHERE  id=$id;";

if(mysql_query($Modifica))
{
echo "

<script>

swal({
  title: 'Realizado',
  text: 'Datos actualizados exitosamente',
  type: 'success',
  showCancelButton: false,
  confirmButtonColor: '#A1D9F2',
  confirmButtonText: 'Continuar',
  closeOnConfirm: true
});



</script>";	
}
else
	{
            
              	echo "

<script>

swal({
  title: 'Error',
  text: 'El registro no pudo ser modificado',
  type: 'error',
  showCancelButton: false,
  confirmButtonColor: '#A1D9F2',
  confirmButtonText: 'Volver atras',
  closeOnConfirm: true
});



</script>";
	}
}
if($sinopsis!="")
{
$Modifica="update pelicula  set sinopsis='".$sinopsis."' WHERE  id=$id;";

if(mysql_query($Modifica))
{
echo "

<script>

swal({
  title: 'Realizado',
  text: 'Datos actualizados exitosamente',
  type: 'success',
  showCancelButton: false,
  confirmButtonColor: '#A1D9F2',
  confirmButtonText: 'Continuar',
  closeOnConfirm: true
});



</script>";	
}
else
	{
            
              	echo "

<script>

swal({
  title: 'Error',
  text: 'El registro no pudo ser modificado',
  type: 'error',
  showCancelButton: false,
  confirmButtonColor: '#A1D9F2',
  confirmButtonText: 'Volver atras',
  closeOnConfirm: true
},
function(){
  window.location='edicion_registros.php';
});



</script>";
	}
}
if($year!="")
{
$Modifica="update pelicula  set year='".$year."' WHERE  id=$id;";

if(mysql_query($Modifica))
{
echo "

<script>

swal({
  title: 'Realizado',
  text: 'Datos actualizados exitosamente',
  type: 'success',
  showCancelButton: false,
  confirmButtonColor: '#A1D9F2',
  confirmButtonText: 'Continuar',
  closeOnConfirm: true
});



</script>";	
}
else
	{
            
              	echo "

<script>

swal({
  title: 'Error',
  text: 'El registro no pudo ser modificado',
  type: 'error',
  showCancelButton: false,
  confirmButtonColor: '#A1D9F2',
  confirmButtonText: 'Volver atras',
  closeOnConfirm: true
},
function(){
  window.location='edicion_registros.php';
});



</script>";
	}
}










	
	
	
	
	




?>
<?php
}
?>