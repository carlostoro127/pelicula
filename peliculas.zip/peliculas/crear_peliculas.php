<?php
error_reporting(0);
include("conexion.php");
session_start();
if(!isset($_SESSION["session_username"])) {
header("location:login_admin.php");
} else {
?>
<html>
<head>
<meta name="tipo_contenido"  content="text/html;" http-equiv="content-type" charset="utf-8">
<title>Creacion de usuarios</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable='0'" />
  <link rel="stylesheet" href="example/example.css">
  
  <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script language="javascript" src="js/generales.js"></script>

  <!-- This is what you need -->
  <script src="dist/sweetalert.min.js"></script>
  <link rel="stylesheet" href="dist/sweetalert.css">
  <!--.......................-->

<style type='text/css'>
        /* Codigo CSS para pagina responsive*/
        @media only screen and (max-width: 630px) {
            body                    { width: 100% !important; -webkit-text-size-adjust: none; }
            table table             { width: 320px !important; }
            .scaleHeader            { width: 320px !important; !important; }
            .scaleFullwidth         { width: 320px !important; !important; }
            .scaleSeperator         { width: 320px !important; }
            .scaleFollowus          { width: 240px !important; }
            .fullWidth              { width: 320px !important; }
            .mobileImage            { margin: 20px auto; }
            .center                 { text-align: center !important; }
            .tableCenter            { margin-left: auto !important; margin-right: auto !important; float: none !important; }
            .columnMargin           { margin-bottom: 20px !important; }
            .button                 { margin-left: auto !important; margin-right: auto !important; float: none !important; }
        }
        .mobileImage {margin: 20px auto; }
        .mobileImage1 {margin: 20px auto; }
.mobileImage1 {margin: 20px auto; }


input[type="file"]#nuestroinput {
 width: 0.1px;
 height: 0.1px;
 opacity: 0;
 overflow: hidden;
 position: absolute;
 z-index: -1;
 }
 
 label[for=" nuestroinput"] {
 font-size: 14px;
 font-weight: 600;
 color: #fff;
 background-color: #106BA0;
 display: inline-block;
 transition: all .5s;
 cursor: pointer;
 padding: 15px 40px !important;
 text-transform: uppercase;
 width: fit-content;
 text-align: center;
 }
  
 input[type="submit"]#nuestroinputsub {
 width: 0.1px;
 height: 0.1px;
 opacity: 0;
 overflow: hidden;
 position: absolute;
 z-index: -1;
 }
 
 label[for=" nuestroinputsub"] {
 font-size: 14px;
 font-weight: 600;
 color: #fff;
 background-color: #106BA0;
 display: inline-block;
 transition: all .5s;
 cursor: pointer;
 padding: 15px 40px !important;
 text-transform: uppercase;
 width: fit-content;
 text-align: center;
 }
 
 
 
 input[type="file"]#nuestroinput1 {
 width: 0.1px;
 height: 0.1px;
 opacity: 0;
 overflow: hidden;
 position: absolute;
 z-index: -1;
 }
 
 label[for=" nuestroinput1"] {
 font-size: 14px;
 font-weight: 600;
 color: #fff;
 background-color: #106BA0;
 display: inline-block;
 transition: all .5s;
 cursor: pointer;
 padding: 15px 40px !important;
 text-transform: uppercase;
 width: fit-content;
 text-align: center;
 }
  
 input[type="submit"]#nuestroinputsub1 {
 width: 0.1px;
 height: 0.1px;
 opacity: 0;
 overflow: hidden;
 position: absolute;
 z-index: -1;
 }
 
 label[for=" nuestroinputsub1"] {
 font-size: 14px;
 font-weight: 600;
 color: #fff;
 background-color: #106BA0;
 display: inline-block;
 transition: all .5s;
 cursor: pointer;
 padding: 15px 40px !important;
 text-transform: uppercase;
 width: fit-content;
 text-align: center;
 }
 
 
 
</style>
<iframe src="sweetalert.html" style="display:none;"></iframe>


<script type="application/javascript">
jQuery('input[type=file]').change(function(){
 var filename = jQuery(this).val().split('\\').pop();
 var idname = jQuery(this).attr('id');
 console.log(jQuery(this));
 console.log(filename);
 console.log(idname);
 jQuery('span.'+idname).next().find('span').html(filename);
});
</script>

</head>

<body>


<img style="position: fixed; z-index: -1; top: 0; left: 0; width: 100%;" src="images/fondo.png" alt="Fondo" />
<script type="text/javascript">
function mostrar1(){
document.getElementById('oculto1').style.display = 'block';
document.getElementById('oculto2').style.display = 'none';
}
</script>
<script type="text/javascript">
function mostrar2(){
document.getElementById('oculto1').style.display = 'none';
document.getElementById('oculto2').style.display = 'block';
}
</script>


<br><br>


<a href="administracion_peliculas.php"><div title="Inicio" style="cursor: pointer; font-family:Arial, Helvetica, Verdana; font-weight: bold; width:40px; height:40px; float:left; margin-left:30px; "><center><img src="images/home_icon.png"  style="width:60px;" alt="home_icon"/></center></div></a>
<a href="logout.php"><div title="Salir" style="cursor: pointer; font-family:Arial, Helvetica, Verdana; font-weight: bold; width:40px; height:40px; float:left; margin-left:1200px; "><center><img src="images/logout.png"  style="width:50px;" alt="home_icon"/></center></div></a>


<br><br><br><br>
<br>

<br><br>




<link rel="stylesheet" href="formoid_files/formoid1/formoid-solid-dark.css" type="text/css" />
<script type="text/javascript" src="formoid_files/formoid1/jquery.min.js"></script>

<!-- Start Formoid form-->
<?php
echo"

<!-- Start Formoid form-->
<link rel='stylesheet' href='formoid_files/formoid1/formoid-solid-red.css' type='text/css' />
<script type='text/javascript' src='formoid_files/formoid1/jquery.min.js'></script>
<form id='formulario' class='formoid-solid-red' style='background-color:#1A2223;font-size:14px;font-family:'Roboto',Arial,Helvetica,sans-serif;color:#34495E;max-width:480px;min-width:150px' method='post' action='registrar_peliculas.php'><div class='title'><h2><strong>Crear pelicula</strong></h2></div>
	<div class='element-input' title='nombre'><label class='title'></label><div class='item-cont'><input title='Digite el nombre completo de la pelicula minimo 5 caracteres' minlength='5' maxlength='50' class='large' type='text' name='nombre' placeholder='Nombre pelicula' required /><span class='icon-place'></span></div></div>
	<div class='element-textarea' title='Sinopsis'><label class='title'></label><div class='item-cont'><textarea class='medium' name='sinopsis' cols='20' rows='5' placeholder='Sinopsis (Opcional)' maxlength='200'></textarea><span class='icon-place'></span></div></div>
	<div class='element-select' title='Año'><label class='title'></label><div class='item-cont'><div class='large'><span>
	<select name='year' required>
<option value=''>Seleccione año de la pelicula</option>";
		 
               $year = date("Y");
                 for ($i= 1980; $i < $year ; $i++) 
				 { 

                 echo'<option VALUE="'.$i.'">'.$i.'</option>';

                     }

                
		echo"
		</select><i></i><span class='icon-place'></span></span></div></div></div>
<div class='submit'><input type='submit' id='btnEnviar' value='crear' name='crear'/></div></form>
<p class='respuesta'>

    <p>
<script src='https://code.jquery.com/jquery-2.2.2.min.js'></script>
    <script src='enviar.js'></script>
<!-- Stop Formoid form-->";
	
?>








</body>
</html>

<?php
}
?>