<?php
error_reporting(0);
include("conexion.php");
session_start();
if(!isset($_SESSION["session_username"])) {
header("location:login_admin.php");
} else {
?>
<html>
<head>
<meta name="tipo_contenido"  content="text/html;" http-equiv="content-type" charset="utf-8">
<title>Creacion de usuarios</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable='0'" />
  <link rel="stylesheet" href="example/example.css">
  
  <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script language="javascript" src="js/generales.js"></script>

  <!-- This is what you need -->
  <script src="dist/sweetalert.min.js"></script>
  <link rel="stylesheet" href="dist/sweetalert.css">
  <!--.......................-->

<style type='text/css'>
        /* Codigo CSS para pagina responsive*/
        @media only screen and (max-width: 630px) {
            body                    { width: 100% !important; -webkit-text-size-adjust: none; }
            table table             { width: 320px !important; }
            .scaleHeader            { width: 320px !important; !important; }
            .scaleFullwidth         { width: 320px !important; !important; }
            .scaleSeperator         { width: 320px !important; }
            .scaleFollowus          { width: 240px !important; }
            .fullWidth              { width: 320px !important; }
            .mobileImage            { margin: 20px auto; }
            .center                 { text-align: center !important; }
            .tableCenter            { margin-left: auto !important; margin-right: auto !important; float: none !important; }
            .columnMargin           { margin-bottom: 20px !important; }
            .button                 { margin-left: auto !important; margin-right: auto !important; float: none !important; }
        }
        .mobileImage {margin: 20px auto; }
        .mobileImage1 {margin: 20px auto; }
.mobileImage1 {margin: 20px auto; }


input[type="file"]#nuestroinput {
 width: 0.1px;
 height: 0.1px;
 opacity: 0;
 overflow: hidden;
 position: absolute;
 z-index: -1;
 }
 
 label[for=" nuestroinput"] {
 font-size: 14px;
 font-weight: 600;
 color: #fff;
 background-color: #106BA0;
 display: inline-block;
 transition: all .5s;
 cursor: pointer;
 padding: 15px 40px !important;
 text-transform: uppercase;
 width: fit-content;
 text-align: center;
 }
  
 input[type="submit"]#nuestroinputsub {
 width: 0.1px;
 height: 0.1px;
 opacity: 0;
 overflow: hidden;
 position: absolute;
 z-index: -1;
 }
 
 label[for=" nuestroinputsub"] {
 font-size: 14px;
 font-weight: 600;
 color: #fff;
 background-color: #106BA0;
 display: inline-block;
 transition: all .5s;
 cursor: pointer;
 padding: 15px 40px !important;
 text-transform: uppercase;
 width: fit-content;
 text-align: center;
 }
 
 
 
 input[type="file"]#nuestroinput1 {
 width: 0.1px;
 height: 0.1px;
 opacity: 0;
 overflow: hidden;
 position: absolute;
 z-index: -1;
 }
 
 label[for=" nuestroinput1"] {
 font-size: 14px;
 font-weight: 600;
 color: #fff;
 background-color: #106BA0;
 display: inline-block;
 transition: all .5s;
 cursor: pointer;
 padding: 15px 40px !important;
 text-transform: uppercase;
 width: fit-content;
 text-align: center;
 }
  
 input[type="submit"]#nuestroinputsub1 {
 width: 0.1px;
 height: 0.1px;
 opacity: 0;
 overflow: hidden;
 position: absolute;
 z-index: -1;
 }
 
 label[for=" nuestroinputsub1"] {
 font-size: 14px;
 font-weight: 600;
 color: #fff;
 background-color: #106BA0;
 display: inline-block;
 transition: all .5s;
 cursor: pointer;
 padding: 15px 40px !important;
 text-transform: uppercase;
 width: fit-content;
 text-align: center;
 }
 
 
 
</style>
<iframe src="sweetalert.html" style="display:none;"></iframe>


<script type="application/javascript">
jQuery('input[type=file]').change(function(){
 var filename = jQuery(this).val().split('\\').pop();
 var idname = jQuery(this).attr('id');
 console.log(jQuery(this));
 console.log(filename);
 console.log(idname);
 jQuery('span.'+idname).next().find('span').html(filename);
});
</script>

</head>

<body>


<img style="position: fixed; z-index: -1; top: 0; left: 0; width: 100%;" src="images/fondo.png" alt="Fondo" />
<script type="text/javascript">
function mostrar1(){
document.getElementById('oculto1').style.display = 'block';
document.getElementById('oculto2').style.display = 'none';
}
</script>
<script type="text/javascript">
function mostrar2(){
document.getElementById('oculto1').style.display = 'none';
document.getElementById('oculto2').style.display = 'block';
}
</script>


<br><br>

<a href="index.php"><div title="Inicio" style="cursor: pointer; font-family:Arial, Helvetica, Verdana; font-weight: bold; width:40px; height:40px; float:left; margin-left:30px; "><center><img src="images/home_icon.png"  style="width:60px;" alt="home_icon"/></center></div></a>
<a href="logout.php"><div title="Salir" style="cursor: pointer; font-family:Arial, Helvetica, Verdana; font-weight: bold; width:40px; height:40px; float:left; margin-left:1200px; "><center><img src="images/logout.png"  style="width:50px;" alt="home_icon"/></center></div></a>

<br><br><br><br>
<br>

<br><br>




<link rel="stylesheet" href="formoid_files/formoid1/formoid-solid-dark.css" type="text/css" />
<script type="text/javascript" src="formoid_files/formoid1/jquery.min.js"></script>

<!-- Start Formoid form-->
<?php
echo"

<!-- Start Formoid form-->
<link rel='stylesheet' href='formoid_files/formoid1/formoid-solid-red.css' type='text/css' />
<script type='text/javascript' src='formoid_files/formoid1/jquery.min.js'></script>
<form id='formulario' class='formoid-solid-red' style='background-color:#1A2223;font-size:14px;font-family:'Roboto',Arial,Helvetica,sans-serif;color:#34495E;max-width:480px;min-width:150px' method='post' action='registrar_usuarios.php'><div class='title'><h2><strong>Crear usuario</strong></h2></div>
	<div class='element-input' title='Nombre'><label class='title'></label><div class='item-cont'><input title='Digite el nombre completo minimo 5 caracteres' minlength='5' maxlength='50' class='large' type='text' name='nombre' placeholder='Nombre completo' required /><span class='icon-place'></span></div></div>
	<div class='element-input' title='Nick name'><label class='title'></label><div class='item-cont'><input title='Digite el nick name solo puede usar letras, numeros y el caracter guion al piso ( _ )' class='large' type='text' name='nickname' placeholder='Nick name' maxLength='60' pattern='[A-Za-z0-9_-]{5,55}' required /><span class='icon-place'></span></div></div>
	<div class='element-password' title='Contraseña'><label class='title'></label><div class='item-cont'><input title='Digite la contraseña colocando una letra en mayuscula y un numero' class='large' type='text' name='PASSWORD' placeholder='Digite la contraseña maximo 8 caracteres' maxLength='8' pattern='[A-Za-z0-9]{5,8}' required /><span class='icon-place'></span></div></div>
<div class='submit'><input type='submit' id='btnEnviar' value='crear' name='crear'/></div></form>
<p class='respuesta'>

    <p>
<script src='https://code.jquery.com/jquery-2.2.2.min.js'></script>
    <script src='enviar.js'></script>
<!-- Stop Formoid form-->";
	
?>








</body>
</html>

<?php
}
?>