<?php
include("conexion.php");
session_start();
if(!isset($_SESSION["session_username"])) {
header("location:login.php");
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Ediciones</title>
	<link rel="stylesheet" href="css/jquery.dataTables.css">
	<script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
	<script src="js/table.js"></script>
	


</head>
<body style="font-family:Arial, Helvetica, Verdana;">
<img style="position: fixed; z-index: -1; top: 0; left: 0; width: 100%;" src="images/fondo.png" alt="Fondo" />
<script type="text/javascript">
function mostrar1(){
document.getElementById('oculto1').style.display = 'block';
document.getElementById('oculto2').style.display = 'none';
}
</script>
<script type="text/javascript">
function mostrar2(){
document.getElementById('oculto1').style.display = 'none';
document.getElementById('oculto2').style.display = 'block';
}
</script>


<br><br>

<a href="administracion_peliculas.php"><div title="Inicio" style="cursor: pointer; font-family:Arial, Helvetica, Verdana; font-weight: bold; width:40px; height:40px; float:left; margin-left:30px; "><center><img src="images/home_icon.png"  style="width:60px;" alt="home_icon"/></center></div></a>
<a href="logout.php"><div title="Salir" style="cursor: pointer; font-family:Arial, Helvetica, Verdana; font-weight: bold; width:40px; height:40px; float:left; margin-left:1200px; "><center><img src="images/logout.png"  style="width:50px;" alt="home_icon"/></center></div></a>


<br><br><br><br>
<br>

<br><br>

<?php



 $query = "SELECT * FROM  pelicula";


    $result = mysql_query($query); 
    $numero_registros = mysql_num_rows($result); 
	
	echo'
	<div style="background-color:#FFF;">
	<table id="tabla" class="display" cellspacing="0"  style="background-color: #FFF; border:1px; margin-top:30px; ">
        <thead>
            <tr>
<th style="background-color: #E74C3C; font-family:Arial, Helvetica, Verdana; color:#FFF;">Nombre pelicula</th>		
<th style="background-color: #E74C3C; font-family:Arial, Helvetica, Verdana; color:#FFF;">Sinopsis</th>		
<th style="background-color: #E74C3C; font-family:Arial, Helvetica, Verdana; color:#FFF;">Año pelicula</th>
<th style="background-color: #E74C3C; font-family:Arial, Helvetica, Verdana; color:#FFF;">Accion</th>
 
            </tr>
        </thead>';
 
     echo"<tbody>";
		while ($registro = mysql_fetch_array($result))
		{ 
echo "
             <tr>
	  <form id='formulario' method='POST' action='actualizar_pelicula.php'>
	  <td style=' font-family:Arial, Helvetica, Verdana;'><input   type='text'  name='nombre' placeholder='$registro[nombre]' /></td>
	  <td style=' font-family:Arial, Helvetica, Verdana;'><input   type='text'  name='sinopsis' placeholder='$registro[sinopsis]' /></td>
	  <td style=' font-family:Arial, Helvetica, Verdana;'><input   type='text'  name='year' placeholder='$registro[year]'/></td>
	  <input   type='hidden'  name='id' value='$registro[id]' />
	  
	  
	  
		
	  <td style=' font-family:Arial, Helvetica, Verdana; color:#FFF;'>
	  <center><input style='float:left; border-radius:10px; border:0px; cursor: pointer; background-color:#E74C3C; font-family:arial,helvetica color:#FFF;' type='submit' id='btnEnviar' name='actualizar' value='actualizar' /></center></form></td>
      	   
            </tr>
             "; 
} 
echo "
        </tbody>
    </table>
	<p class='respuesta'>

    <p>

    <script src='enviar_act.js'></script>
	</div>";
	?> 
</body>
</html>
<?php
}
?>
