<?php
include("conexion.php");

session_start();
if(!isset($_SESSION["session_username"])) {
header("location:login.php");
} else {
?>
<head>
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable='0'" />
  <title>Creando</title>
  
  <link rel="stylesheet" href="example/example.css">
  <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>

  <!-- This is what you need -->
  <script src="dist/sweetalert.min.js"></script>
  <link rel="stylesheet" href="dist/sweetalert.css">
  <!--.......................-->
  </head>
  <iframe src="sweetalert.html" style="display:none;"></iframe>
<?php



$NOMBRE=$_REQUEST['nombre'];
$sinopsis=$_REQUEST['sinopsis'];
$year=$_REQUEST['year'];






 



$sql="INSERT INTO pelicula(nombre, sinopsis, year) VALUES ('".$NOMBRE."', '".$sinopsis."', '".$year."');";

if(mysql_query($sql)){

echo "
<script>
swal({
  title: 'Realizado',
  text: 'Pelicula creada exitosamente',
  type: 'success',
  showCancelButton: false,
  confirmButtonColor: '#A1D9F2',
  confirmButtonText: 'Continuar',
  closeOnConfirm: true
});



</script>



</script>";

	
	}//final if principal
	
	
	else
	{
            //si aparece esto es posible que el archivo no tenga el formato adecuado
              	
		echo "

<script>

swal({
  title: 'Error',
  text: 'La pelicula no pudo ser creada',
  type: 'error',
  showCancelButton: false,
  confirmButtonColor: '#A1D9F2',
  confirmButtonText: 'Volver atras',
  closeOnConfirm: true
},
function(){
  window.location='crear_peliculas.php';
});



</script>";

	}






mysql_close();
?>
<?php
}
?>